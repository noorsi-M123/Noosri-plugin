<?php
/**
 * Plugin Name:       Noorsi Synercom
 * Description:       Deze plugin verwijst klanten met 1 klik naar Calendly
 * Version:           1.3
 * Requires at least: 6.0.0
 * Requires PHP:      7.2
 * Author:            Mohammad Noorsi

 */

//=============================================================================================================================
// Algemene instellingen
//=============================================================================================================================

// Voorkom directe toegang.

if(!defined('ABSPATH')){
    echo "Wat probeer jij te doen  ";
    exit;

}

// Plugin activering hook.
register_activation_hook(__FILE__, function() {
    flush_rewrite_rules(); // flush rewrite rules
});

// Plugin deactivering hook.
register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules(); // flush rewrite rules
});


//=============================================================================================================================
// Style toevoegen
//=============================================================================================================================
wp_enqueue_style( 'noorsi-css', plugin_dir_url( __FILE__ ) . 'style.css', [], '1.0.0', 'all' );

//=============================================================================================================================
// Deze functie zorgt ervoor dat de plugin niet in de backend van wordpress gaat werken
//=============================================================================================================================
add_action( 'wp_footer', function() {
    if( is_admin() ) {
        exit;
    }
    ?>
    <aside class="noorsi">
        <article class="block-01">
            <p>Waarom een <span>kennismakingsgesprek</span> maken? <br> Omdat,</p>
            <a href="https://calendly.com/synercom/kennismakingsgesprek">kennismakingsgesprek</a>
        </article>

        <article class="block-02">
            <p>Waarom een <span>Meeting</span> maken? <br> Omdat,</p>
            <a href="https://calendly.com/synercom/meeting-20-minuten">Meeting</a>
        </article>

        <article class="block-03">
            <p>Waarom een <span>Social Media Strategiesessie</span> maken? <br> Omdat,</p>
            <a href="https://calendly.com/synercom/60min">Social Media Strategiesessie</a>
        </article>
    </aside>
    <?php
});









































