
<?php
/**
 * Plugin Name: Synercom Noorsi Plugin
 */



echo '<form class="go"  method="POST" action="https://calendly.com/synercom/kennismakingsgesprek
">
    <button class="button" name="send"> Kennismakingsgesprek </button>
  
  </form>';

echo '<form method="POST" action="https://calendly.com/synercom/meeting-20-minuten
">
    <button class="button" name="send"> Meeting 20 Min </button>
  </form>';

echo '<form method="POST" action=" https://calendly.com/synercom/60min
">
    <button class="button" name="send"> Social Media Strategiesessie
 </button>
  </form>';

//}
