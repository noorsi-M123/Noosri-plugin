<!DOCTYPE html>
<html>
<head>
    <title>Page Title</title>
    <link href="style.css">
</head>
<body>
    <?php
    include ("my-plugin1.php");
    ?>
    <style>
    <?php
    include ("style.css")
    ;?></style>
    <!-- <form action="POST" action="https://calendly.com/synercom/kennismakingsgesprek
"> <button name="send"> afspraak </button> </form>
-->
</body>
</html>